Kodi RTP Play addon
=========================

![Addon icon](https://github.com/enen92/plugin.video.rtpplay/blob/master/icon.png?raw=true)

RTP Play video addon for Kodi Entertainment Center. Watch Live and On-Demand broadcasts from RTP, portuguese public TV and Radio station.
*This plugin is open-source and not endorsed by RTP.*


