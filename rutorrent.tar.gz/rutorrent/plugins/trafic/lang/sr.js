﻿/*
 * PLUGIN TRAFFIC
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.traf 		= "Саобраћај";
 theUILang.perDay		= "Дневно";
 theUILang.perMonth		= "Месечно";
 theUILang.perYear		= "Годишње";
 theUILang.allTrackers		= "Сви тракери";
 theUILang.ClearButton		= "Очисти";
 theUILang.ClearQuest		= "Do you really want to clear statistics for selected tracker(s)?";
 theUILang.selectedTorrent	= "Selected torrent(s)";
 theUILang.ratioDay		= "Ratio/day";
 theUILang.ratioWeek		= "Ratio/week";
 theUILang.ratioMonth		= "Ratio/month";
