﻿/*
 * PLUGIN TRAFFIC
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.traf 		= "Tráfico";
 theUILang.perDay		= "Por dia";
 theUILang.perMonth		= "Por mes";
 theUILang.perYear		= "Por año";
 theUILang.allTrackers		= "Todos los trackers";
 theUILang.ClearButton		= "Borrar";
 theUILang.ClearQuest		= "Realmente desea borrar las estadísticas de los trackers seleccionados?";
 theUILang.selectedTorrent	= "Torrent(s) seleccionado";
 theUILang.ratioDay		= "Ratio/dia";
 theUILang.ratioWeek		= "Ratio/semana";
 theUILang.ratioMonth		= "Ratio/mes";
