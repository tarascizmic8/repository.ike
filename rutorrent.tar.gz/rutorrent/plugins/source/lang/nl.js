﻿/*
 * PLUGIN SOURCE
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.getSource		= "Download .torrent";
 theUILang.cantFindTorrent	= "Torrent file voor deze download niet gevonden.";

thePlugins.get("source").langLoaded();