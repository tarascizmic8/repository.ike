﻿/*
 * PLUGIN SOURCE
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.getSource		= "Отримати файл .torrent";
 theUILang.cantFindTorrent	= "Вихідний файл .torrent недоступний для цього завантаження.";

thePlugins.get("source").langLoaded();