﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.exFFMPEG		= "Στιγμιότυπα";
 theUILang.exFrameWidth 	= "Πλάτος καρέ";
 theUILang.exFramesCount	= "Αριθμός καρέ";
 theUILang.exStartOffset	= "Έναρξη λήψεων ύστερα από";
 theUILang.exBetween		= "Διάστημα μεταξύ καρέ";
 theUILang.exSave		= "Αποθήκευση";
 theUILang.exSaveAll		= "Αποθ. όλων";
 theUILang.exScreenshot 	= "Στιγμιότυπο";
 theUILang.exPlayInterval	= "Χρόνος εναλλαγής εικόνων παρουσίασης";
 theUILang.exImageFormat	= "Τύπος εικόνας";

thePlugins.get("screenshots").langLoaded();