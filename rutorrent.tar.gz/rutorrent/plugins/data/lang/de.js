﻿/*
 * PLUGIN DATA
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.getData		= "Get File";
 theUILang.cantAccessData	= "Webserver user can't access the data of this torrent.";

thePlugins.get("data").langLoaded();