﻿/*
 * PLUGIN _TASK
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.tskCommand		= "Uruchomione...";
 theUILang.tskCommandDone	= "Gotowe.";
 theUILang.tskConsole		= "Konsola";
 theUILang.tskErrors		= "Diagnostyka";
 theUILang.tskBackground	= "Ukryj";
 theUILang.tskStart		= "Rozpoczęty";
 theUILang.tskFinish		= "Zakończony";
 theUILang.tskElapsed		= "Upłynęło";
 theUILang.tskPlugin		= "Plugin";
 theUILang.tskDeletePrompt	= "Czy na pewno chcesz usunać zaznaczone zadanie(a)?";
 theUILang.tskDelete		= "Usuń zadania(e)";
 theUILang.tskActivate		= "Aktywuj";
 theUILang.tskRemove		= "Usuń";
 theUILang.tskRefresh		= "Odśwież";
 theUILang.tskRunning		= "Uruchomiony";
 theUILang.tskArg		= "Parametr";
 theUILang.tskTasks		= "Zadania";

thePlugins.get("_task").langLoaded();
