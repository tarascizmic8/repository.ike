﻿/*
 * PLUGIN RUTRACKER_CHECK
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.checkTorrent 	= "Kiểm tra xem có cập nhật";
 theUILang.chkHdr		= "Kiểm tra cập nhật Torrent";
 theUILang.checkedAt		= "Lần kiểm tra cuối";
 theUILang.checkedResult	= "Kết quả";
 theUILang.chkResults		= [
 				  "Đang thực hiện",
 				  "Cập nhật",
 				  "Không yêu cầu cập nhật",
 				  "Có thể đã xóa",
 				  "Lỗi truy cập máy theo dỗi",
 				  "Lỗi giao tiếp với rTorrent",
 				  "Không cần thiết"
 				  ];

thePlugins.get("rutracker_check").langLoaded();