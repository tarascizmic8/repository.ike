﻿/*
 * PLUGIN FEEDS
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.feedAll		= "Усі завантаження";
 theUILang.feedCompleted	= "Завершені завантаження";
 theUILang.feedDownloading	= "Незавершені завантаження";
 theUILang.feedActive		= "Активні завантаження";
 theUILang.feedInactive 	= "Неактивні завантаження";
 theUILang.feedError		= "Завантаження з помилками";

thePlugins.get("feeds").langLoaded();