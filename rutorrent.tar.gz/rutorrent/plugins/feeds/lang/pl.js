﻿/*
 * PLUGIN FEEDS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.feedAll		= "Wszystkie torrenty";
 theUILang.feedCompleted	= "Kompletne torrenty";
 theUILang.feedDownloading	= "Pobierane torrenty";
 theUILang.feedActive		= "Aktywne torrenty";
 theUILang.feedInactive 	= "Nieaktywne torrenty";
 theUILang.feedError		= "Torrenty z błędem";

thePlugins.get("feeds").langLoaded();