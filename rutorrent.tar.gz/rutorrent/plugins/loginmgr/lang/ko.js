﻿/*
 * PLUGIN LoginMGR
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.accLogin		= "로그인";
 theUILang.accPassword		= "비밀번호";
 theUILang.accAccounts		= "계정";
 theUILang.accAuto		= "자동 로그인";
 theUILang.acAutoNone		= "하지 않음";
 theUILang.acAutoDay		= "매일";
 theUILang.acAutoWeek		= "매주";
 theUILang.acAutoMonth		= "매달";

thePlugins.get("loginmgr").langLoaded();
