﻿/*
 * PLUGIN LoginMGR
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.accLogin		= "Όνομα Χρήστη";
 theUILang.accPassword		= "Κωδικός Πρόσβασης";
 theUILang.accAccounts		= "Λογαριασμοί";
 theUILang.accAuto		= "Αυτόματη Σύνδεση";
 theUILang.acAutoNone		= "Ποτέ";
 theUILang.acAutoDay		= "Κάθε μέρα";
 theUILang.acAutoWeek		= "Κάθε βδομάδα";
 theUILang.acAutoMonth		= "Κάθε μήνα";

thePlugins.get("loginmgr").langLoaded();