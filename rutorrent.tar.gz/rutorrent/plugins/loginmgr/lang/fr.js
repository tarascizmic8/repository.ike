﻿/*
 * PLUGIN LoginMGR
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.accLogin		= "Nom d'utilisateur";
 theUILang.accPassword		= "Mot de passe";
 theUILang.accAccounts		= "Comptes";
 theUILang.accAuto		= "Autologin";
 theUILang.acAutoNone		= "Jamais";
 theUILang.acAutoDay		= "Tous les jours";
 theUILang.acAutoWeek		= "Toutes les semaines";
 theUILang.acAutoMonth		= "Tous les mois";

thePlugins.get("loginmgr").langLoaded();