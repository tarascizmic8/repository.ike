﻿/*
 * PLUGIN LoginMGR
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Passwort";
 theUILang.accAccounts		= "Accounts";
 theUILang.accAuto		= "Autologin";
 theUILang.acAutoNone		= "Nie";
 theUILang.acAutoDay		= "Jeden Tag";
 theUILang.acAutoWeek		= "Jede Woche";
 theUILang.acAutoMonth		= "Jeden Monat";

thePlugins.get("loginmgr").langLoaded();