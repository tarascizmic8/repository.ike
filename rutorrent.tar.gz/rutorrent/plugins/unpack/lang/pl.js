﻿/*
 * PLUGIN UNPACK
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.unpack		= "Rozpakuj";
 theUILang.unpackPath		= "Rozpakuj do (zostaw puste, aby rozpakować do bieżącego folderu)";
 theUILang.unzipNotFound	= "Unpack plugin: User rTorrenta nie ma dostępu do programu 'unzip'.";
 theUILang.unrarNotFound	= "Unpack plugin: User rTorrenta nie ma dostępu do programu 'unrar'.";
 theUILang.unpackEnabled	= "Enable autounpacking if torrent's label matches filter";
 theUILang.unpackTorrents	= "Dopisz do ścieżki podczas rozpakowywania";
 theUILang.unpackAddLabel	= "Etykieta Torrenta";
 theUILang.unpackAddName	= "Nazwa Torrenta";

thePlugins.get("unpack").langLoaded();