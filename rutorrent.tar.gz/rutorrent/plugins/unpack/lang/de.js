﻿/*
 * PLUGIN UNPACK
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.unpack		= "Entpacken";
 theUILang.unpackPath		= "Entpacken nach (Leer lassen für das aktuelle Verzeichniss des Torrents)";
 theUILang.unzipNotFound	= "Unpack Plugin: rTorrent Benutzer kann nicht auf 'unzip' Programm zugreifen.";
 theUILang.unrarNotFound	= "Unpack Plugin: rTorrent Benutzer kann nicht auf 'unrar' Programm zugreifen.";
 theUILang.unpackEnabled	= "Aktivieren Sie automatisches Entpacken, wenn das Label vom Torrent mit dem Filter übereinstimmt";
 theUILang.unpackTorrents	= "Anhängen an Pfadname beim Auspacken von Torrentdaten";
 theUILang.unpackAddLabel	= "Torrent Label";
 theUILang.unpackAddName	= "Torrent Name";

thePlugins.get("unpack").langLoaded();