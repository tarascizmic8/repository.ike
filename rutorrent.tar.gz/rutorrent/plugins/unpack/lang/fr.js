/*
 * PLUGIN UNPACK
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.unpack		= "Décompression";
 theUILang.unpackPath		= "Décompresser vers (vide = dossier du torrent)";
 theUILang.unzipNotFound	= "Plug-in 'Unpack': rTorrent ne peut pas accéder au programme 'unzip'.";
 theUILang.unrarNotFound	= "Plug-in 'Unpack': rTorrent ne peut pas accéder au programme 'unrar'.";
 theUILang.unpackEnabled	= "Activer la décompression auto si l'étiquette correspond au filtre";
 theUILang.unpackTorrents	= "Lors de la décompression d'un torrent, ajouter au nom du dossier";
 theUILang.unpackAddLabel	= "Étiquette du torrent";
 theUILang.unpackAddName	= "Nom du torrent";

thePlugins.get("unpack").langLoaded();

