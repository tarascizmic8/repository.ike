﻿/*
 * PLUGIN MEDIAINFO
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.mediainfo		= "Інформація про файл";