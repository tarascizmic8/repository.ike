﻿/*
 * PLUGIN MEDIAINFO
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";