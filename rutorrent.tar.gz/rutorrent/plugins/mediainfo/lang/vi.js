﻿/*
 * PLUGIN MEDIAINFO
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.mediainfo		= "Thông tin định dạng";