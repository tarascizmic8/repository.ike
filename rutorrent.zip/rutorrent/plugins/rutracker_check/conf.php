<?php

$updateInterval 	= 60;	// in minutes, zero for disable
