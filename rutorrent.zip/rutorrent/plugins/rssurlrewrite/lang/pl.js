﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.rssNewRule		= "Nowa reguła";
 theUILang.mnu_rssurlrewrite	= "Zastępstwo URLa w RSS";
 theUILang.rssRulesManager	= "Menedżer reguł";
 theUILang.rssAddRule		= "Dodaj";
 theUILang.rssDelRule		= "Usuń";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "Ustawienia Reguł";
 theUILang.rssSrcHref		= "Jeśli URL torrenta pokrywa się z maską";
 theUILang.rssSrcGuid		= "Jeśli URL opisu torrenta pokrywa się z maską";
 theUILang.rssDstHref		= "to zastąp URL z";
 theUILang.rssDstGuid		= "to zastąp URL opisu z";
 theUILang.rssRulesDebug	= "Rule Debug";
 theUILang.rssTestString	= "Test";
 theUILang.rssTestResult	= "Wynik";
 theUILang.rssURLInfo		= "URL info";
 theUILang.rssURLGUID		= "URL opisu";
 theUILang.rssURLHref		= "Download URL";
 theUILang.rssPatternError	= "Błąd w masce.";
 theUILang.rssStatus		= "RSS"; 

thePlugins.get("rssurlrewrite").langLoaded();