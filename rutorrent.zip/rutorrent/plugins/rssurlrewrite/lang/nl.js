﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.rssNewRule		= "Nieuwe regel";
 theUILang.mnu_rssurlrewrite	= "Vervangende URL in RSS";
 theUILang.rssRulesManager	= "Regel manager";
 theUILang.rssAddRule		= "Toevoegen";
 theUILang.rssDelRule		= "Verwijderen";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "Regel instellingen";
 theUILang.rssSrcHref		= "Wanneer de URL gelijk is aan";
 theUILang.rssSrcGuid		= "Als de beschrijving van de torrent-URL's gelijk is aan";
 theUILang.rssDstHref		= "Vervang de laad URL door";
 theUILang.rssDstGuid		= "vervang de URL van de omschrijving naar";
 theUILang.rssRulesDebug	= "Debug Regel";
 theUILang.rssTestString	= "Test";
 theUILang.rssTestResult	= "Resultaat";
 theUILang.rssURLInfo		= "URL info";
 theUILang.rssURLGUID		= "URL-omschrijving";
 theUILang.rssURLHref		= "Laad URL";
 theUILang.rssPatternError	= "Fout in patroon string.";
 theUILang.rssStatus		= "RSS";

thePlugins.get("rssurlrewrite").langLoaded();