﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.rssNewRule		= "Новое правило";
 theUILang.mnu_rssurlrewrite	= "Замена URL в RSS";
 theUILang.rssRulesManager	= "Менеджер правил";
 theUILang.rssAddRule		= "Добавить";
 theUILang.rssDelRule		= "Удалить";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "Параметры правила";
 theUILang.rssSrcHref		= "Если URL загрузки торрента совпадает с шаблоном";
 theUILang.rssSrcGuid		= "Если URL описания торрента совпадает с шаблоном";
 theUILang.rssDstHref		= "то заменить URL загрузки торрента на";
 theUILang.rssDstGuid		= "то заменить URL описания торрента на";
 theUILang.rssRulesDebug	= "Проверка правила";
 theUILang.rssTestString	= "Тест";
 theUILang.rssTestResult	= "Результат";
 theUILang.rssURLInfo		= "Информация об URL";
 theUILang.rssURLGUID		= "URL описания";
 theUILang.rssURLHref		= "URL загрузки";
 theUILang.rssPatternError	= "Ошибка в оформлении шаблона.";
 theUILang.rssStatus		= "Рассылка"; 

thePlugins.get("rssurlrewrite").langLoaded();