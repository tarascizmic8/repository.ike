<?php

$theSettings->registerEventHook($plugin["name"],"RSSFetched");
$theSettings->registerPlugin($plugin["name"],$pInfo["perms"]);
