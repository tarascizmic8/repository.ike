﻿/*
 * PLUGIN MEDIAINFO
 *
 * Latvian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";