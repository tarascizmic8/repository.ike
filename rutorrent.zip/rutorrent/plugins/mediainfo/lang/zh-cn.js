﻿/*
 * PLUGIN MEDIAINFO
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";