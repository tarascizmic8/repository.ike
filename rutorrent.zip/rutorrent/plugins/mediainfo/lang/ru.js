﻿/*
 * PLUGIN MEDIAINFO
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Информация о файле";