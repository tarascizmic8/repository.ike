﻿/*
 * PLUGIN DATA
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.getData		= "Verkrijg data";
 theUILang.cantAccessData	= "Web-server user heeft geen toegang tot de data van deze torrent.";

thePlugins.get("data").langLoaded();