﻿/*
 * PLUGIN DATA
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.getData		= "Получить файл";
 theUILang.cantAccessData	= "Пользователь веб-сервера не имеет доступа к данным этого торрента.";

thePlugins.get("data").langLoaded();