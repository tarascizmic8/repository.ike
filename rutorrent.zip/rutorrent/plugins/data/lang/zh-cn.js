﻿/*
 * PLUGIN DATA
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.getData		= "获取数据";
 theUILang.cantAccessData	= "Webserver user can't access the data of this torrent.";

thePlugins.get("data").langLoaded();