﻿/*
 * PLUGIN COOKIES
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.cookiesDesc = "Cookies (格式: 主机|cookie1;cookie2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();